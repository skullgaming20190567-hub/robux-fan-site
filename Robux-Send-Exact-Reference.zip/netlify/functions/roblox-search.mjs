export default async (request) => {
  const url = new URL(request.url);
  const keyword = (url.searchParams.get("keyword") || "").trim();
  const json = (body, status = 200) => new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "access-control-allow-origin": "*" }
  });
  if (keyword.length < 3) return json({ users: [] });
  try {
    const searchUrl = new URL("https://users.roblox.com/v1/users/search");
    searchUrl.searchParams.set("keyword", keyword);
    searchUrl.searchParams.set("limit", "10");
    const headers = {
      "accept": "application/json",
      "user-agent": "Mozilla/5.0 (compatible; RobloxFanSite/1.0)"
    };
    const response = await fetch(searchUrl, { headers });
    if (!response.ok) return json({ users: [], error: `Roblox search returned HTTP ${response.status}` }, 502);
    const payload = await response.json();
    const matches = Array.isArray(payload.data) ? payload.data : [];
    const ids = matches.map(u => u.id).filter(Boolean);
    let avatarById = {};
    if (ids.length) {
      try {
        const thumb = new URL("https://thumbnails.roblox.com/v1/users/avatar-headshot");
        thumb.searchParams.set("userIds", ids.join(","));
        thumb.searchParams.set("size", "150x150");
        thumb.searchParams.set("format", "Png");
        thumb.searchParams.set("isCircular", "true");
        const tr = await fetch(thumb, { headers });
        if (tr.ok) {
          const td = await tr.json();
          for (const item of (td.data || [])) if (item.imageUrl) avatarById[item.targetId] = item.imageUrl;
        }
      } catch (_) {}
    }
    return json({ users: matches.map(u => ({
      id: u.id, name: u.name, displayName: u.displayName,
      avatarUrl: avatarById[u.id] || null,
      hasVerifiedBadge: !!u.hasVerifiedBadge
    })) });
  } catch (e) {
    return json({ users: [], error: "Roblox user search request failed." }, 502);
  }
};
